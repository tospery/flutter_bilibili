import 'package:flutter/material.dart';
import 'package:flutter_bili_app/model/video_model.dart';
import 'package:flutter_bili_app/navigator/hi_navigator.dart';

class HomeTabPage extends StatefulWidget {
  final String name;

  const HomeTabPage({Key? key,required this.name}) : super(key: key);

  @override
  _HomeTabPageState createState() => _HomeTabPageState();
}

class _HomeTabPageState extends State<HomeTabPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [Text(widget.name),MaterialButton(onPressed: ()=>{
          HiNavigator.getInstance().onJumpTo(RouteStatus.detail, args: {'videoMo':VideoModel(1)})
        },child: Text('跳转详情页'),)],
      ),
    );
  }
}
